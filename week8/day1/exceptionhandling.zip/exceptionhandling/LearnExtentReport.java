package exceptionhandling;

import java.io.IOException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class LearnExtentReport {

	public static void main(String[] args) throws IOException {
		
  //step:1 Setup the path for your report		
   ExtentHtmlReporter report=new ExtentHtmlReporter("./reports/record.html");
  
   //Step:2 to get your actual data
    ExtentReports extent=new ExtentReports();
    //to hold the history in the report
    report.setAppendExisting(true);      
	//step:3 to record your report into html reporter
	extent.attachReporter(report);	
	
	//to add the testcase 
	ExtentTest createTest = extent.createTest("LoginPage", "Verifying the functionality of loginpage with Positive Credential");
	createTest.assignAuthor("Vidya");
	createTest.assignCategory("SmokeTest");
	
	//status of the report
	//createTest.pass("Login is successful");
	createTest.fail("Login is unsuccessful",
			MediaEntityBuilder.createScreenCaptureFromPath("./snaps/img.png").build());
	
	//important step -to generate the report
	extent.flush();
	
	}

}
