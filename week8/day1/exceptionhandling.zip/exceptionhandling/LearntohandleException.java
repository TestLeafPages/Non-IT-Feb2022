package exceptionhandling;

public class LearntohandleException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int x=5;
		int y=0;
		String s = null;
		int ph=0;
		int[] a= {1,2,3};
		
		//try with multiple block
		try {
			int length = s.length();
			System.out.println(length);
			try {
				System.out.println(a[3]);
			}catch(ArrayIndexOutOfBoundsException t) {
				System.out.println(a[2]);
			}
			
		} catch (NullPointerException N) {
			s="vidya";
			System.out.println(s);
		}catch(ArithmeticException A){
			if(ph<10) {
			System.out.println("Provide proper input");}
			else {
				System.out.println("ph is valid");
			}
		}catch(Exception e) {
			System.out.println(e);
			
		}
		
		//try-catch block
		
		try {
			int z=x/y;//this may throw error	
			System.out.println(z);
		} catch (ArithmeticException e) {
			System.out.println(e);			
		}
		
	
		
		
		System.out.println("Division done sucessfully");
		
	}

}
