package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import baseclass.ProjectSpecficMethod;
import pages.Loginpage;

public class TC001_LoginLogout extends ProjectSpecficMethod{

	@BeforeTest
	public void setData() {
		testName="LoginLogout";
		testDesc="Positive funtionality of logintest";
		testCategory="SmokeTest";
		testAuthor="Vidya";
	}
	
	@Test
	public void runLoginLogout() throws IOException {
		//System.out.println(driver);
		new Loginpage(driver)		
		.enterUsername().enterPassword().clickLogin().clickLogout();
		
		
		
		
	}
	
	
}
