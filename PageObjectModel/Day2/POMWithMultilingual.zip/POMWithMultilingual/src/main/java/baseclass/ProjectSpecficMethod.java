package baseclass;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import io.github.bonigarcia.wdm.WebDriverManager;
import utils.ReadExcel;

public class ProjectSpecficMethod {

	public ChromeDriver driver;
	public String excelfile;
	public FileInputStream input;
	public Properties prop;

	@Parameters("language")
	@BeforeMethod
	public void preConditions(String language) throws IOException {
		
		  if(language.equals("English")) { 
			  input=new
		  FileInputStream("./prop/English.properties");
		  prop =new Properties();
		  prop.load(input); }else if(language.equals("French")) {
		  
		  input=new FileInputStream("./prop/French.properties"); prop =new
		  Properties(); prop.load(input); 
		  }
		 
		/*
		 * input = new FileInputStream("./prop/"+language+".properties"); prop = new
		 * Properties(); prop.load(input);
		 */

		System.out.println(prop.getProperty("url"));

		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		// to read the url value from property file

		driver.get(prop.getProperty("url"));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

	}

	@AfterMethod
	public void postConditons() {
		driver.close();
	}

	@DataProvider()
	public String[][] sendData() throws IOException {
		return ReadExcel.readData(excelfile);
	}

}
