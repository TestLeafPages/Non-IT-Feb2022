package exceptionhandling;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class LearnThrows {

	public int calculate(int x, int y) throws FileNotFoundException {
		int z=0;
		if(y==0) {			
			FileInputStream fis=new FileInputStream("./data/language.properties");
			throw new RuntimeException("Provide a valid value to Y,check your input");
		}
		else {
		 z=x/y;
		
		}return z;
	}	
	public static void main(String[] args) throws FileNotFoundException {
	
		LearnThrows lt =new LearnThrows();
		int calculate = lt.calculate(15, 10);
		System.out.println(calculate);
		
		FileInputStream fis=new FileInputStream("./data/language.properties");
		
	}

}
