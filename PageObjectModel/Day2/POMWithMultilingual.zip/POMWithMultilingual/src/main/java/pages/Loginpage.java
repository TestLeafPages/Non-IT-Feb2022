package pages;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import baseclass.ProjectSpecficMethod;

public class Loginpage extends ProjectSpecficMethod {
	
	public Loginpage(ChromeDriver driver,Properties prop) {
		this.driver=driver;
		this.prop=prop;
	}
	
	public Loginpage enterUsername() {
		driver.findElement(By.id("username")).sendKeys(prop.getProperty("username"));
		/*
		 * Loginpage lp=new Loginpage(); return lp;
		 */
		return this;	}

	public Loginpage enterPassword() {
		driver.findElement(By.id("password")).sendKeys(prop.getProperty("password"));
		return this;

	}

	public HomePage clickLogin() {
		driver.findElement(By.className("decorativeSubmit")).click();
		/*
		 * HomePage hp= new HomePage(); return hp;
		 */
		return new HomePage(driver,prop);
	}

}
