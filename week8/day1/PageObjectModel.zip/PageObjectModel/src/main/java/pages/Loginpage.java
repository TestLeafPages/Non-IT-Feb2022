package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import baseclass.ProjectSpecficMethod;

public class Loginpage extends ProjectSpecficMethod {

	public Loginpage(ChromeDriver driver) {
		this.driver = driver;
	}

	public Loginpage enterUsername() throws IOException {

				
			try {
				driver.findElement(By.id("username")).sendKeys("DemosalesManager");
				testStatus("Entered the u successfully","pass");
				} catch (Exception e) {
				// TODO Auto-generated catch block
					testStatus("Entered the u successfully","fail");
			}
		
		   

		return this;

	}

	public Loginpage enterPassword() throws IOException {

		try {
			driver.findElement(By.id("password")).sendKeys("crmsfa");
			testStatus("Entered the password successfully","pass");
		} catch (Exception e) {
			testStatus("Entered the password is unsuccessful","fail");
		}
		return this;
	}

	public HomePage clickLogin() throws IOException {
		try {
			driver.findElement(By.className("decorativeSubmit")).click();
			testStatus("pass", "Login is successful");
		} catch (Exception e) {
			testStatus("fail", "Login is unsuccessful");
		}
		return new HomePage(driver);
	}

}
