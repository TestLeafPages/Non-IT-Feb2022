package exceptionhandling;

public class LearntryFinallyblock {

	public static void main(String[] args) {
		
		int x=5;
		int y=0;
		int z;
		
		String s=null;
//		
//		try {
//			z = x / y;
//			
//		} finally {
//			System.out.println("The final block");
//		}

		try {
			z = x / y;
			System.out.println(s.length());
		}catch(Exception e) {
			z=x/(y+2);
			System.out.println(z);
			System.out.println(e);
		}
		finally {
			System.out.println("Executing the finally block");
			
		}
		
	}

}
