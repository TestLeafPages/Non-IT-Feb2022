package pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import baseclass.ProjectSpecficMethod;

public class Loginpage extends ProjectSpecficMethod {
	
	public Loginpage(ChromeDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
		
	}
	

	
	// @CacheLookup//to make the execution faster
	// And Condition
	
	/*
	 * @FindBys ({
	 * 
	 * @FindBy(how=How.ID,using="username"),
	 * 
	 * @FindBy(how=How.XPATH,using="//input[@name='USERNAME']") }) WebElement
	 * eleUsername;
	 */
	 
	@FindBy(how=How.XPATH,using="//input[@class='inputLogin']")  List<WebElement> eleusername;
	
	//or condition
	/*
	 * @FindAll ({
	 * 
	 * @FindBy(how=How.ID,using="username"),
	 * 
	 * @FindBy(how=How.NAME,using="USERNAME") }) WebElement eleUsername;
	 */
	
	@FindBy(how=How.ID,using="password") WebElement elepwd;
	@FindBy(how=How.CLASS_NAME,using="decorativeSubmit") WebElement eleLogin;
	
	

	
	public Loginpage enterUsername() {
	//	driver.findElement(By.id("username")).sendKeys("DemosalesManager");
		/*
		 * Loginpage lp=new Loginpage(); return lp;
		 * 
		 */
		eleusername.get(0).sendKeys("DemosalesManager");
		
		return this;	}

	public Loginpage enterPassword() {
		eleusername.get(1).sendKeys("crmsfa");
		return this;

	}

	public HomePage clickLogin() {
		eleLogin.click();
		/*
		 * HomePage hp= new HomePage(); return hp;		 */

		return new HomePage(driver);
	}

}
