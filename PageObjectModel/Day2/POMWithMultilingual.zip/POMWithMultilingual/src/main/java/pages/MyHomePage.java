package pages;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import baseclass.ProjectSpecficMethod;

public class MyHomePage extends ProjectSpecficMethod{

	public MyHomePage(ChromeDriver driver,Properties prop) {
		this.driver=driver;
		this.prop=prop;
	}
	
	
	public MyHomePage verifyHomePage() {
		System.out.println(driver.getTitle());
		return this;
	}
	
	public MyLeadsPage LeadLink() {
		driver.findElement(By.linkText(prop.getProperty("leadslink"))).click();
	return new MyLeadsPage(driver);
	}
	
	
}
