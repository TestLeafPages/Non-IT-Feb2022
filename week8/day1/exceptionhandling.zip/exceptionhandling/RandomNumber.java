package exceptionhandling;

public class RandomNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int random = (int) (Math.random()* 99999);
	
		System.out.println(random);
		
		
	}

}
