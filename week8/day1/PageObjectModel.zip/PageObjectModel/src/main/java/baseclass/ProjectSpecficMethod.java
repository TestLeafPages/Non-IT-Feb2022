package baseclass;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.github.bonigarcia.wdm.WebDriverManager;
import utils.ReadExcel;

public class ProjectSpecficMethod {

	public ChromeDriver driver;
	public String excelfile;
	public static ExtentHtmlReporter report;
	public static ExtentReports extent;
	public static ExtentTest createTest;
	public String testName, testDesc, testAuthor, testCategory;

	@BeforeSuite
	public void startReport() {
		report = new ExtentHtmlReporter("./reports/record.html");
		extent = new ExtentReports();
		report.setAppendExisting(true);
		extent.attachReporter(report);
	}

	@BeforeClass
	public void testDetails() {
		createTest = extent.createTest(testName, testDesc);
		createTest.assignAuthor(testAuthor);
		createTest.assignCategory(testCategory);
	}

	public void testStatus(String message,String status) throws IOException {
		// pass and fail
		if (status.equalsIgnoreCase("pass")) {
			createTest.pass(message,MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/shot"+takeSnap()+".png").build());
		} else if (status.equalsIgnoreCase("fail")) {
			createTest.fail(message,MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/shot"+takeSnap()+".png").build());
		}
	}

	public int takeSnap() throws IOException {
	int random = (int) (Math.random()* 99999);
	File screenshotAs = driver.getScreenshotAs(OutputType.FILE);
	File dest=new File("./snaps/img"+random+".png");
	FileUtils.copyFile(screenshotAs, dest);
	return random;
	}
	
	
	@BeforeMethod
	public void preConditions() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps/control/main");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

	}

	@AfterMethod
	public void postConditons() {
		driver.close();
	}

	@DataProvider()
	public String[][] sendData() throws IOException {
		return ReadExcel.readData(excelfile);
	}

	@AfterSuite
	public void endReport() {
		extent.flush();
	}

}
