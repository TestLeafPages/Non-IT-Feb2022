package pages;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import baseclass.ProjectSpecficMethod;

public class HomePage extends ProjectSpecficMethod{
	public HomePage(ChromeDriver driver,Properties prop) {
		this.driver=driver;
		this.prop=prop;
	}

	public MyHomePage clickCrmSfa() {
		driver.findElement(By.linkText(prop.getProperty("Crmsfalink"))).click();
		return new MyHomePage(driver,prop);
		
	}	
	public Loginpage clickLogout() {
	driver.findElement(By.className(prop.getProperty("Logout"))).click();
	return new Loginpage(driver,prop);
	}
	
		
	
}
